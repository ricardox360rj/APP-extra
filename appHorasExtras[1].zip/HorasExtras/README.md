# Horas Extras (Android)

App Android que embute a página `app/src/main/assets/index.html` em uma WebView.
Os registros e configurações ficam salvos no próprio aparelho (localStorage).

## Gerar o APK

**Android Studio (mais simples)**
1. Abra a pasta `HorasExtras` no Android Studio (Ladybug ou mais recente) e aguarde o sync do Gradle.
2. Para testar: conecte o celular com depuração USB e clique em Run.
3. Para um APK: `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
   O arquivo sai em `app/build/outputs/apk/debug/app-debug.apk`.

**Linha de comando** (precisa de JDK 17, Gradle 8.9+ e do Android SDK; defina `ANDROID_HOME`)
```
gradle assembleDebug
```

Para instalar o APK no celular, copie o arquivo e permita a instalação de fontes desconhecidas.
Para publicar na Play Store, gere um APK/AAB assinado em `Build > Generate Signed Bundle / APK`.

## Alterar o app
Edite `app/src/main/assets/index.html`; nada mais precisa mudar.
